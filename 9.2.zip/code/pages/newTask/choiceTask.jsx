import React, {useState} from 'react'
import {Input} from "antd";
import styles from './index.css';

export default function ({task = {}, setTask}) {

  return (
    <div>
      <div className={styles.row}>
        <span className={styles.key}>question</span>
        <span className={styles.value}>
          <Input placeholder={'Enter question'} value={task.question}
                 onChange={event => setTask({question: event.target.value})}/>
        </span>
        &nbsp;&nbsp;&nbsp;Yes/No

      </div>
    </div>
  );
}
