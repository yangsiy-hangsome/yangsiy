import styles from './index.css';
import React, {useMemo, useState} from 'react'
import {message, Col, Radio, Button, Input, DatePicker} from 'antd'
import request from 'umi-request'
import moment from 'moment'
import {useSetState, useRequest} from 'ahooks'
import ChoiceTask from './choiceTask'
import DecisionTask from './decisionTask'
import SentenceTask from './sentenceTask'


const taskType = {
  choice: 'choice task',
  decision: 'decision-making task',
  sentence: 'sentence-level task',
}
const addTask = (data) => {
  return request('http://localhost:9091/task/add', {method: 'POST', data})
}
const defaultTask = {type: 'choice', master: 'yes',options:[]}
export default function () {
  const [task, setTask] = useSetState(defaultTask)
  const {loading, run: doAdd} = useRequest(addTask, {
    manual: true, onSuccess: () => {
      message.success('save success')
      setTask(pre=>{
        const newState={}
        Object.keys(pre).forEach(key=>{
          newState[key]=''
        })
        return {...newState,...defaultTask}
      })
    }
  })
  return (
    <div className={styles.newTask}>
      <h3>Select Task Type</h3>
      <Radio.Group value={task.type} onChange={e => setTask({type: e.target.value})}>
        {Object.keys(taskType).map(item => (<Radio key={item} value={item}>{taskType[item]}</Radio>))}
      </Radio.Group>
      <h3 style={{marginTop: 24}}>Describe your task to Workers</h3>
      <div className={styles.row}>
        <span className={styles.key}>Title</span>
        <span className={styles.value}>
          <Input placeholder={'Enter task title'}
                 value={task.title}
                 onChange={event => setTask({title: event.target.value})}/>
        </span>
      </div>
      <div className={styles.row}>
        <span className={styles.key}>Description</span>
        <span className={styles.value}>
          <Input placeholder={'Enter task description'}
                 value={task.description}
                 onChange={event => setTask({description: event.target.value})}/>
        </span>
      </div>
      <div className={styles.row}>
        <span className={styles.key}>Expire Date</span>
        <span className={styles.value}>
          <DatePicker format={'YYYY-MM-DD'}
                      value={task.expire && moment(task.expire, 'YYYY-MM-DD')}
                      onChange={(date, dateString) => setTask({expire: dateString})}/>
        </span>
      </div>
      <h3 style={{marginTop: 24}}>Setting up your task</h3>
      <div style={{padding: 24}}>
        {task.type === 'choice' && <ChoiceTask task={task} setTask={setTask}/>}
        {task.type === 'decision' && <DecisionTask task={task} setTask={setTask}/>}
        {task.type === 'sentence' && <SentenceTask task={task} setTask={setTask}/>}
      </div>
      <h3 style={{marginTop: 24}}>Worker Requirement</h3>
      <div className={styles.row2}>
        <span className={styles.key}>Require Master Workers</span>
        <span className={styles.value}>
          <Radio.Group value={task.master} onChange={e => setTask({master: e.target.value})}>
            <Radio key={'yes'} value={'yes'}>yes</Radio>
            <Radio key={'no'} value={'no'}>no</Radio>
          </Radio.Group>
        </span>
      </div>
      <div className={styles.row2}>
        <span className={styles.key}>Reward per response</span>
        <span className={styles.value}>
          <Input value={task.reward}
                 onChange={event => setTask({reward: event.target.value})}/>
        </span>
      </div>
      <div className={styles.row2}>
        <span className={styles.key}>Number of workers</span>
        <span className={styles.value}>
          <Input value={task.number}
                 onChange={event => setTask({number: event.target.value})}/>
        </span>
      </div>
      <div><Button style={{float: 'right'}} loading={loading} onClick={() => {
        doAdd(task)
      }}>Save</Button></div>
    </div>
  );
}
