import React from 'react'
import request from "umi-request";
import {useRequest} from "ahooks";

const getTasks = () => {
  return request('http://localhost:9091/task/all')
}
export default function () {
  const {data} = useRequest(getTasks)
  console.log(JSON.stringify(data,null,4));
  return (
    <pre>
      {JSON.stringify(data,null,4)}
    </pre>
  );
}
