import styles from './index.css';
import faker from "faker";
import React, {useMemo} from 'react'
import {Row, Col} from 'antd'

export default function () {
  const data = useMemo(() => {
    const result = []
    for (let i = 0; i < 10; i++) {
      result.push({
        desc: faker.lorem.text(),
        name: faker.name.findName(),
        img: faker.image.image(160, 100)
      })
    }
    return result
  }, [])
  return (
    <div className={styles.wrap}>
      <img className={styles.topImg} src={faker.image.image(200, 100)}/>
      <Row gutter={16}>
        {data.map(item => (
          <Col span={8}>
            <img src={item.img} style={{width: '100%'}}/>
            <div style={{fontWeight: 'bold'}}>{item.name}</div>
            <div className={styles.desc}>{item.desc}</div>
          </Col>
        ))}</Row>
    </div>
  );
}
