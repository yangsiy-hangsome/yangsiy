import React from 'react'
import faker from 'faker';

export default function () {

  return (
    <div>
      {faker.lorem.paragraphs()}
    </div>
  );
}
