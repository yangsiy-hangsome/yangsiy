import styles from './index.css';
import {Menu,Button} from 'antd';
import {router} from 'umi'
import {useLocation} from 'dva'
import config from '../../.umirc'
import Bottom from '../components/Bottom'

const {routes} = config.routes[0]

function BasicLayout(props) {
  const {pathname} = useLocation()
  return (
    <div>
      <div className={styles.top}>
        <span className={styles.logo}>ICrowdTask</span>
        <Menu className={styles.menu} mode="horizontal" selectedKeys={[pathname]}>
          {routes.filter(item => item.name).map(item => (
            <Menu.Item key={item.path} onClick={() => router.push(item.path)}>{item.name}</Menu.Item>
          ))}
        </Menu>
        <Button type={"primary"}>Sign in</Button>
      </div>
      <div className={styles.content}>
        {props.children}
      </div>
      <Bottom/>
    </div>
  );
}

export default BasicLayout;
