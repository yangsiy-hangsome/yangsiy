import styles from './index.css';
import {Input, Button} from 'antd'

export default function () {
  return (
    <div className={styles.wrap}>
      NEWSLETTER SIGN&nbsp;
      &nbsp;<Input style={{width: 200}} placeholder={'Enter your email'}/>
      &nbsp;&nbsp;<Button>subscribe</Button>
      <div style={{flex: 1}}/>
      <span>CONNECT US</span>
    </div>
  );
}
