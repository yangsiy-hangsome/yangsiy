const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/crowd-task');

const Task = mongoose.model('Task', {
  type: String,
  master: String,
  title: String,
  description: String,
  expire: String,
  question: String,
  options:[],
  reward: String,
  number: String
});

const add = (task) => {
  return new Task(task).save()
}

module.exports = {
  add, Task
}


