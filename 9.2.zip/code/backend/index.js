const express = require('express')
var bodyParser = require('body-parser');
const app = express()
const port = 9091
const cors = require('cors')
const {add,Task} = require('./db')

app.use(cors())
app.use(bodyParser.json());

app.get('/task/all',async (req,res)=>{
  const tasks= await Task.find()
  console.log(tasks);
  res.json(tasks)
})

app.post('/task/add', async (req, res) => {
  const task = req.body
  await add(task)
  res.json({code: 0})
})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
