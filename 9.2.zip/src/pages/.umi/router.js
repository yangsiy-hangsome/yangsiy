import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__index" */ '../../layouts/index'),
        })
      : require('../../layouts/index').default,
    routes: [
      {
        path: '/index.html',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__index" */ '../index'),
            })
          : require('../index').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__index" */ '../index'),
            })
          : require('../index').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/how',
        name: 'how it works',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__how" */ '../how'),
            })
          : require('../how').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/requesters',
        name: 'requesters',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__requesters" */ '../requesters'),
            })
          : require('../requesters').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/workers',
        name: 'workers',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__workers" */ '../workers'),
            })
          : require('../workers').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/pricing',
        name: 'pricing',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__pricing" */ '../pricing'),
            })
          : require('../pricing').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/about',
        name: 'about',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__about" */ '../about'),
            })
          : require('../about').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/new-task',
        name: 'new requester task',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__newTask" */ '../newTask'),
            })
          : require('../newTask').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        path: '/worker-tasks',
        name: 'worker tasks',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__workerTasks" */ '../workerTasks'),
            })
          : require('../workerTasks').default,
        exact: true,
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
      {
        component: () =>
          React.createElement(
            require('/Users/xiaguisheng/gus/temp/crowd-task/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: 'crowd-task',
        _title_default: 'crowd-task',
      },
    ],
    _title: 'crowd-task',
    _title_default: 'crowd-task',
  },
  {
    component: () =>
      React.createElement(
        require('/Users/xiaguisheng/gus/temp/crowd-task/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
    _title: 'crowd-task',
    _title_default: 'crowd-task',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return <Router history={history}>{renderRoutes(routes, props)}</Router>;
  }
}
