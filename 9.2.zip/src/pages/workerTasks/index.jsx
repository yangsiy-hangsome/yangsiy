import React, {useState, useEffect} from 'react'
import request from "umi-request";
import {useRequest} from "ahooks";
import {Collapse, Radio, Input, Checkbox, DatePicker, Button} from 'antd';
import moment from "moment";
import styles from "@/pages/newTask/index.css";

const {Panel} = Collapse;
const getTasks = () => {
  return request('http://localhost:9091/task/all')
}
const delTasks = (data) => {
  return request('http://localhost:9091/task/del', {data, method: 'POST'})
}
const editTasks = (data) => {
  return request('http://localhost:9091/task/edit', {data, method: 'POST'})
}

export default function () {
  const [orData, setOrData] = useState()
  const [data, setData] = useState()
  const {run} = useRequest(getTasks, {
    manual: true, onSuccess: data1 => {
      setOrData(data1)
      setData(data1.filter(item => {
        let flag = true;
        if (title && item.title && !item.title.includes(title)) {
          flag = false
        }
        if (expire && item.expire !== expire) {
          flag = false
        }
        return flag
      }))
    }
  })
  useEffect(() => {
    run()
  }, [])

  const [title, setTitle] = useState()
  const [expire, setExpire] = useState()
  const [imgTags, setImgTags] = useState()
  const [mediaTexts, setMediaTexts] = useState()
  return (
    <>
      <Input style={{width: 200}} placeholder={'title'} value={title} onChange={event => setTitle(event.target.value)}/>
      <DatePicker
        placeholder={'expire'}
        style={{margin: 36}}
        format={'YYYY-MM-DD'}
        value={expire && moment(expire, 'YYYY-MM-DD')}
        onChange={(date, dateString) => setExpire(dateString)}/>
      <Button
        onClick={() => {
          if (!data) return
          setData(orData.filter(item => {
            let flag = true;
            if (title && item.title && !item.title.includes(title)) {
              flag = false
            }
            if (expire && item.expire !== expire) {
              flag = false
            }
            return flag
          }))
        }}>filter out</Button>
      <Collapse>
        {data && data.map(item => (
          <Panel
            header={<>title:{item.title}<span
              style={{margin: '0 40px'}}>description:{item.description}</span>
              expire:{item.expire}
              <Button style={{float: 'right'}} onClick={(e) => {
                e.stopPropagation()
                delTasks({id: item._id}).then(() => {
                  run()
                })
              }}>delete</Button></>}
            key={item._id}>

            <div className={styles.row2}>
              <span className={styles.key}>Require Master Workers</span>
              <span className={styles.value}>
                {item.master}
              </span>
            </div>
            <div className={styles.row2}>
              <span className={styles.key}>Reward per response</span>
              <span className={styles.value}>
                {item.reward}
              </span>
            </div>
            <div className={styles.row2}>
              <span className={styles.key}>Number of workers</span>
              <span className={styles.value}>
                {item.number}
              </span>
            </div>


            <div style={{padding: 48}}>
              {item.type === 'choice' && <><h3>{item.question}</h3>
                <div><Radio.Group defaultValue={'yes'}>
                  <Radio value={'yes'} key={'yes'}>Yes</Radio>
                  <Radio value={'no'} key={'no'}>No</Radio>
                </Radio.Group>
                </div>
              </>}
              {item.type === 'decision' && <><h3>{item.question}</h3>
                <div>
                  {item.options.map(opt => (
                    <Checkbox>{opt}</Checkbox>
                  ))}
                </div>
              </>}
              {item.type === 'sentence' && <><h3>{item.question}</h3>
                <div>
                  <Input style={{width: '100%'}} placeholder={'enter your anwser'}/>
                </div>
              </>}
              {item.type === 'image' && <><h3>tag objects found in image</h3>
                <div>
                  <img style={{width: 300}} src={'http://localhost:9091' + item.imageUrl}/>
                </div>
                <div>
                  <Input style={{width: '100%', marginTop: 16}} placeholder={'enter objects'}
                         value={imgTags||item.imgTags}
                         onChange={event => setImgTags(event.target.value)}/>
                  <Button onClick={()=>editTasks({id:item._id,imgTags,mediaTexts})}>Save</Button>
                </div>
              </>}
              {item.type === 'media' && <><h3>convert speech to text</h3>
                {item.medias && item.medias.map(m => (
                  <>
                    <div>
                      {!m.endsWith('mp4') && <audio src={'http://localhost:9091' + m} controls='controls'/>}
                      {m.endsWith('mp4') && <video src={'http://localhost:9091' + m} controls='controls'/>}
                    </div>
                    <div>
                    </div>
                  </>
                ))}
                <Input style={{width: '100%', margin: '16px 0'}} placeholder={'enter text'}
                       value={mediaTexts||item.mediaTexts}
                       onChange={event => setMediaTexts(event.target.value)}/>
                <Button onClick={()=>editTasks({id:item._id,imgTags,mediaTexts})}>Save</Button>
              </>}
            </div>
          </Panel>
        ))}
      </Collapse>
    </>
  );
}
