import React, {useState} from 'react'
import {Upload,Button} from "antd";
import styles from './index.css';



export default function ({task = {}, setTask}) {
  const {medias=[]} =task
  const handleChange = info => {
    if (info.file.status === 'done') {
      setTask({medias:[...medias,info.file.response.url]})
    }
  };
  return (
    <div>
      <div className={styles.row}>
        <div>convert speech to text</div>
        <br/>
        <Upload
          name="file"
          showUploadList={false}
          action="http://localhost:9091/uploads"
          onChange={handleChange}
        >
          <Button>Upload</Button>
        </Upload>
        {medias.map(item=>(
          <div>{item}</div>
        ))}
      </div>
    </div>
  );
}
