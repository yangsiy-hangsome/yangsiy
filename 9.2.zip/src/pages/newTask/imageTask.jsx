import React, {useState} from 'react'
import {Upload,message} from "antd";
import styles from './index.css';


function beforeUpload(file) {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('You can only upload JPG/PNG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJpgOrPng && isLt2M;
}


export default function ({task = {}, setTask}) {
  const {imageUrl} =task
  const handleChange = info => {
    if (info.file.status === 'done') {
      setTask({imageUrl:info.file.response.imgPath})
    }
  };
  return (
    <div>
      <div className={styles.row}>
        <div>tag objects found in image</div>
        <br/>
        <Upload
          name="img"
          listType="picture-card"
          showUploadList={false}
          style={{width:300}}
          action="http://localhost:9091/upload"
          beforeUpload={beforeUpload}
          onChange={handleChange}
        >
          {imageUrl ? <img src={'http://localhost:9091'+imageUrl} alt="img" style={{width: '100%'}}/> :
            <div style={{marginTop: 8}}>Upload</div>}
        </Upload>
      </div>
    </div>
  );
}
