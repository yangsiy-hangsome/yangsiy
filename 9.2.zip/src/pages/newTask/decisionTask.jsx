import React, {useState} from 'react'
import styles from "./index.css";
import {Input, Button} from "antd";

export default function ({task = {}, setTask}) {
  const [option, setOption] = useState()
  const {options = []} = task
  console.log(task);
  return (
    <div>
      <div className={styles.row}>
        <span className={styles.key}>question</span>
        <span className={styles.value}>
          <Input placeholder={'Enter question'} value={task.question}
                 onChange={event => setTask({question: event.target.value})}/></span>
      </div>
      <div className={styles.row}>
        <span className={styles.key}>option</span>
        <span className={styles.value}>
          <Input placeholder={'Enter option'}
                 value={option}
                 onChange={event => setOption(event.target.value)}/>
        </span>
        &nbsp;&nbsp;&nbsp;<Button onClick={() => {
        if (!option) return
        setOption()
        setTask({options: [...options, option]})
      }}>Add</Button>
      </div>
      {options.map((item, index) => (
        <div style={{marginLeft: 24}}>
          {index + 1}. {item}
        </div>
      ))}
    </div>
  );
}
