export default {
  publicPath: './',
  exportStatic: {
    // htmlSuffix: true,
    // dynamicRoot: true,
  },
  treeShaking: true,
  routes: [
    {
      path: '/',
      component: '../layouts/index',
      routes: [
        { path: '/', component: '../pages/index' },
        { path: '/how',name:'how it works', component: '../pages/how' },
        { path: '/requesters', name:'requesters',component: '../pages/requesters' },
        { path: '/workers', name:'workers',component: '../pages/workers' },
        { path: '/pricing', name:'pricing',component: '../pages/pricing' },
        { path: '/about', name:'about',component: '../pages/about' },
        { path: '/new-task', name:'new requester task',component: '../pages/newTask' },
        { path: '/worker-tasks', name:'worker tasks',component: '../pages/workerTasks' },
      ]
    }
  ],
  plugins: [
    ['umi-plugin-react', {
      antd: true,
      dva: true,
      dynamicImport: { webpackChunkName: true },
      title: 'crowd-task',
      dll: false,

      routes: {
        exclude: [
          /models\//,
          /services\//,
          /model\.(t|j)sx?$/,
          /service\.(t|j)sx?$/,
          /components\//,
        ],
      },
    }],
  ],
}
