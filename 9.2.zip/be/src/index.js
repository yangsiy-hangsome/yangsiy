const express = require('express')
const bodyParser = require('body-parser');
const app = express()
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const port = 9091
const cors = require('cors')
const {add, del, edit, Task} = require('./db')

app.use(cors())
app.use(bodyParser.json());

app.get('/task/all', async (req, res) => {
  const tasks = await Task.find()
  console.log(tasks);
  res.json(tasks)
})

app.post('/task/add', async (req, res) => {
  const task = req.body
  await add(task)
  res.json({code: 0})
})

app.post('/task/del', async (req, res) => {
  const {id} = req.body
  await del(id)
  res.json({code: 0})
})

app.post('/task/edit', async (req, res) => {
  const {id, imgTags, mediaTexts} = req.body
  await edit(id, {imgTags, mediaTexts})
  res.json({code: 0})
})

app.use('/public', express.static(path.join(__dirname, '../www')))
app.post('/upload', multer().single('img'), (req, res) => {
  let {buffer, mimetype} = req.file;
  let fileName = (new Date()).getTime() + parseInt(Math.random() * 3435) + parseInt(Math.random() * 6575);
  let fileType = mimetype.split('/')[1];

  fs.writeFile(path.join(__dirname, `../www/images/${fileName}.${fileType}`), buffer, (data) => {
    if (data) {
      console.log(data);
      res.json({code: -1, msg: "上传失败"})
    } else {
      res.json({code: 0, msg: "上传成功", imgPath: `/public/images/${fileName}.${fileType}`})
    }
  })
})
app.post('/uploads', multer().single('file'), (req, res) => {
  let {buffer, mimetype} = req.file;
  let fileName = (new Date()).getTime() + parseInt(Math.random() * 3435) + parseInt(Math.random() * 6575);
  let fileType = mimetype.split('/')[1];

  fs.writeFile(path.join(__dirname, `../www/files/${fileName}.${fileType}`), buffer, (data) => {
    if (data) {
      console.log(data);
      res.json({code: -1, msg: "上传失败"})
    } else {
      res.json({code: 0, msg: "上传成功", url: `/public/files/${fileName}.${fileType}`})
    }
  })
})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
