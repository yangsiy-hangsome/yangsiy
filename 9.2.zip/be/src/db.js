const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/crowd-task');

const Task = mongoose.model('Task', {
  type: String,
  master: String,
  title: String,
  description: String,
  expire: String,
  question: String,
  imageUrl: String,
  medias: [],
  options: [],
  reward: String,
  number: String,
  imgTags: '',
  mediaTexts: '',
});

const add = (task) => {
  return new Task(task).save()
}

const del = id => {
  return Task.deleteOne({_id: id})
}
const edit = (id, data) => {
  return Task.updateOne({_id: id}, data)
}

module.exports = {
  add, del, edit, Task
}


